package com.example.youtubeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoutubeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(YoutubeApiApplication.class, args);
	}

}
